'''

.. This software is released under an MIT/X11 open source license.
   Copyright 2015 Diffeo, Inc.
'''
