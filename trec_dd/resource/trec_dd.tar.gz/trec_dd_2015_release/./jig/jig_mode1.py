'''
    jig mode1 for trec-dd

    ----

    Copyright 2015 InfoSense Group, Georgetown University
'''

import os
import argparse
import xml.etree.ElementTree as ET
import json
from subprocess import check_output

cut_off = 0.42

parser = argparse.ArgumentParser(description="Call trec-dd interactive system, mode1")
parser.add_argument('-i', '--index', help='provide index path for mode 1', required=False)
parser.add_argument('-r', '--runid', help='provide runid, required for mode 1', required=True)
parser.add_argument('args', nargs='*', help='topic_id and docnos')

args = parser.parse_args()

tree = ET.parse('./truth_data/truth_data.xml')
root = tree.getroot()

topic_node = root.findall(".//topic[@id='%s']"%args.args[0])[0]
passage_nodes = topic_node.findall('.//passage')

dh = open('./.similarity_truth/%s'%args.runid,'a')

rlist = [[],[],[],[],[]]
score_dict = [{},{},{},{},{}]

if args.index:
	doc_content = []
	for i in range(1,len(args.args)):
		doc_content.append(check_output(['./bin/getParseDoc', args.args[i], args.index]))

for passage_node in passage_nodes:
	subtopic_id = topic_node.findall(".//passage[@id='%s']/.."%passage_node.get('id'))[0].get('id')
	passage_content = None
	passage_id = passage_node.get('id')
	passage_rating = passage_node.findall('rating')[0].text
	passage_docno = passage_node.findall('docno')[0].text

	for i,docno in enumerate(args.args[1:]):
		if passage_docno == docno:
			if subtopic_id in score_dict[i]:
				score_dict[i][subtopic_id]['num'] += 1
				score_dict[i][subtopic_id]['score'] += float(passage_rating)	
			else:
				score_dict[i][subtopic_id] = {'num':1, 'score': float(passage_rating)}
			rlist[i].append((subtopic_id, passage_id, passage_rating, '1'))
		elif args.index: ## index path is provided, do similarity check
			if not passage_content:
				passage_content = check_output(['./bin/krovetz_stem', passage_node.findall('text')[0].text])
			similarity = check_output(['./bin/cosine_similarity', passage_content, doc_content[i]]).strip('\n')
			if float(similarity) >= cut_off:
				if subtopic_id in score_dict[i]:
					score_dict[i][subtopic_id]['num'] += 1
					score_dict[i][subtopic_id]['score'] += int(passage_rating)*float(similarity)	
				else:
					score_dict[i][subtopic_id] = {'num':1, 'score': int(passage_rating)*float(similarity)}
				rlist[i].append((subtopic_id, passage_id, passage_rating, similarity))

for i, doc_score in enumerate(score_dict): ## generate score table for cube test
	for subtopic_id in doc_score.keys():
		dh.write(' '.join([args.args[0], subtopic_id, args.args[i+1], str(doc_score[subtopic_id]['score']/doc_score[subtopic_id]['num'])])+'\n')	

dh.close()

print json.dumps(rlist)
