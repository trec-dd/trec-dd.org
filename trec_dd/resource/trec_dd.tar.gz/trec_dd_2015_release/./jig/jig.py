'''
    jig simulator for TREC Dynamic Domain systems, providing feedbacks for each submission

    ----

    Copyright 2015 InfoSense Group, Georgetown University
'''


import argparse
import os
from subprocess import call

parser = argparse.ArgumentParser(description="Call trec-dd interactive system")
parser.add_argument('-o', '--option', help='select interactive mode', required=True)
parser.add_argument('-c', '--config', help='provide config file for mode 2', required=False)
parser.add_argument('-i', '--index', help='provide index path for mode 1', required=False)
parser.add_argument('-r', '--runid', help='provide runid, required for mode 1', required=True)
parser.add_argument('args', nargs='*', help='input for given command')

args = parser.parse_args()

if args.option == 'mode1':
	if args.index:
	    alist = ['-i',args.index] + ['-r', args.runid] + args.args
	else:
	    alist = ['-r', args.runid] + args.args
	call(['python','jig/jig_mode1.py'] + alist)
elif args.option == 'mode2':
	call(['python','trec_dd_harness','-c',args.config] + args.args)
else:
	print "option parameter should be \"mode1\" or \"mode2\""

