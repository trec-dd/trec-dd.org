/*******************************
 *  ** Copyright 2015 InfoSense Group, Georgetown Umiversity
 *   ********************************/
#ifndef _ParaSearch_H
#define _ParaSearch_H

#include <iostream>
using std::cout;
using std::endl;
#include <vector>
#include "indri/QueryEnvironment.hpp"
#include "indri/QueryAnnotation.hpp"
#include "indri/ScoredExtentResult.hpp"
#include "indri/SnippetBuilder.hpp"
#include <string>
using std::string;

/**
 * A class that generates all parent and child relationship between all terms
 *
 * @author Jiyun Luo [http://cs-class.uis.georgetown.edu/~jl1749/homepage/]
 * @version 12/28/12 
 */
class ParaSearch{
private:
  //index path
  string _indexPath;

  string URLDecodeString(string s);

  void split(const string &s, char delim, std::vector<string> &elems);
  
  char fromHex(char c1, char c2);
public:
  indri::api::QueryEnvironment * _env;

  ParaSearch(string& indexPath);

  ~ParaSearch();

  /**
   * Open the QueryEnvironment _env specified by CATB_INDEX_PATH
  */
  void openIndex();

  size_t getDocLength(string *docID);

}; // class ParaSearch

#endif //_ParaSearch_H
