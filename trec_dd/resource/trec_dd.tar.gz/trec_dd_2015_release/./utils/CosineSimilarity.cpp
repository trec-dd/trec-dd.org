/*******************************
 *  * Copyright 2015 InfoSense Group, Georgetown Umiversity
 *   *******************************/
#include <math.h>
#include <iostream>
#include <stdio.h>
#include <map>
#include <queue>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <utility>
#include <iterator>
#include <indri/QueryEnvironment.hpp>
#include <indri/XMLReader.hpp>
#include <indri/SnippetBuilder.hpp>
#include <indri/KrovetzStemmer.hpp>
#include <indri/QueryExpander.hpp>
#include <indri/RMExpander.hpp>
#include <indri/ParsedDocument.hpp>
#include <unordered_map>

double similarity(std::string content1, std::string content2){
        std::stringstream doc1(content1);
        std::string word1;
        std::unordered_map<std::string, int> docTf1;
        std::unordered_map<std::string, int>::iterator itDoc1;
        while (doc1 >> word1) {
               itDoc1 = docTf1.find(word1);
               if(itDoc1 != docTf1.end()){
                  itDoc1->second ++;
               }else{
                  docTf1[word1] = 1;
               }
        }

        double mod1=0;
        for(itDoc1 = docTf1.begin(); itDoc1 != docTf1.end(); ++itDoc1){
               mod1 += pow(itDoc1->second, 2);
        }
	mod1 = sqrt(mod1);

        std::stringstream doc2(content2);
        std::string word2;
        std::unordered_map<std::string, int> docTf2;
        std::unordered_map<std::string, int>::iterator itDoc2;
        while (doc2 >> word2) {
               itDoc2 = docTf2.find(word2);
               if(itDoc2 != docTf2.end()){
                  itDoc2->second ++;
               }else{
                  docTf2[word2] = 1;
               }
        }

        double mod2=0;
        for(itDoc2 = docTf2.begin(); itDoc2 != docTf2.end(); ++itDoc2){
               mod2 += pow(itDoc2->second, 2);
        }
	mod2 = sqrt(mod2);
	
        double docProduct = 0;
        std::unordered_map<std::string, int>  docTf3 = docTf1;
        if(docTf1.size() > docTf2.size()){
                docTf1 = docTf2;
		docTf2 = docTf3;
        }

        for(itDoc1=docTf1.begin(); itDoc1!=docTf1.end(); ++itDoc1){
                std::string term = itDoc1->first;
                itDoc2 = docTf2.find(term);
                if(itDoc2 != docTf2.end()){
                        docProduct += itDoc1->second * itDoc2->second;
                }
        }

        double cosineSim = docProduct /(mod1 * mod2);
        return cosineSim;
}

void usage(){
  cout << "system parameters missing! 2 parameters needed. agr1 is content1 and arg2 is content2." << endl;
}

#define REQUIRE_ARGS(n) { if( argc < n ) { usage(); return -1; } }

int main ( int argc, char** argv ) {
   try {
       REQUIRE_ARGS(2);
       string content1 = argv[1];
       string content2 = argv[2];

       double cosineSim = similarity(content1, content2);

       cout << cosineSim  << endl;
   } catch ( ... ) {
      cout<< "default error!" << endl;
      return -1;
   }

   return 0;
}


