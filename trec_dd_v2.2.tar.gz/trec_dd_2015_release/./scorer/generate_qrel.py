import os
import xml.etree.ElementTree as ET
import math
import sys

def main():
    tree = ET.parse(sys.argv[1])
    root = tree.getroot()

    domain_nodes = root.findall('.//domain')
    for domain_node in domain_nodes:
        did = int(domain_node.get('id'))
        topic_nodes = domain_node.findall('./topic')
        for topic_node in topic_nodes:
            tid = int(topic_node.get('id'))
            subtopic_nodes = topic_node.findall('./subtopic')
            for subtopic_node in subtopic_nodes:
                sid = int(subtopic_node.get('id'))
		dict = {}

                passages = subtopic_node.findall('./passage')
                for passage in passages:
                    pid = passage.get('id')
                    docno = passage.find('./docno').text
                    text = passage.find('./text').text
                    rating = int(passage.find('./rating').text)
                    type = passage.find('./type').text
		    
		    if rating < 1:
			rating = 1
		    qrel = rating
                    if type == 'MATCHED':
                        score == float(passage.find('./score').text)
			if score:
			   qrel = rating * score
                    else: score = None
		  
		    if docno in dict:
			dict[docno].append(qrel)
		    else:
			dict[docno] = [qrel];
		    
		for key,val in dict.iteritems():
			val.sort(reverse=True)
			#print tid, ' ', sid, ' ',key, val
			final_qrel = 0			
			rank = 0;
			for element in val:
			    rank += 1
			    discount = math.log(rank+1,2)
			    final_qrel += element / discount
	    		print tid, ' ', sid, ' ', key, ' ', "%.3f"%final_qrel

if __name__ == '__main__':
    main()
