/*******************************
 * This software is released under an MIT/X11 open source license. Copyright 2015 @ Georgetown University
 *******************************/
#include <math.h>
#include <iostream>
#include <stdio.h>
#include <map>
#include <queue>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <utility>
#include <iterator>
#include <indri/QueryEnvironment.hpp>
#include <indri/SnippetBuilder.hpp>
#include <indri/KrovetzStemmer.hpp>
#include <indri/QueryExpander.hpp>
#include <indri/RMExpander.hpp>
#include <indri/ParsedDocument.hpp>
#include <unordered_map>

struct passage_data{
        int id;
        std::string docno;
        int rating;
        std::string text;
};

struct subtopic_data{
        std::string name;
        int id;
        int num_of_passages;

        std::vector<struct passage_data> passages;
};

struct topic_data{
        std::string name;
        int id;
        int num_of_subtopics;

        std::vector<struct subtopic_data> subtopics;
};

struct domain_data {
        std::string name;
        int id;
        int num_of_topics;

        std::vector<struct topic_data> topics;
};

std::string exec(char* cmd) {
    FILE* pipe = popen(cmd, "r");
    if (!pipe) return "ERROR";
    char buffer[5000];
    std::string result = "";
    while(!feof(pipe)) {
    	if(fgets(buffer, 5000, pipe) != NULL)
    		result += buffer;
    }
    pclose(pipe);
    return result;
}

std::string trim(std::string const& str)
{
    if(str.empty())
        return str;

    std::size_t first = str.find_first_not_of(' ');
    std::size_t last  = str.find_last_not_of(' ');
    return str.substr(first, last-first+1);
}

void print_usage(char *prog)
{
        cout << "Usage:";
        cout << prog << " -topics=<topic file> -domain=<current domain> -runid=<run tag> -index=<repository> -config=<configuration file> [-topicNum=<topic id> -count=<result number> -rule=<smoothing rules>]" << endl;

	cout << "Detail:" << endl;
	cout << "topic file: the topics.xml file" << endl;
	cout << "current domain: one string from the following list Illicit_Goods/Ebola/Local_Politics/Polar" << endl;
	cout << "run tag: name for a run" << endl;
	cout << "repository: Indri index built for a domain" << endl;
	cout << "configuration file: the configuration file used to call jig" << endl;
	cout << "topic id: topic id" << endl;
	cout << "result number: number of retrieval results for a topic, default is 200" << endl;
	cout << "smoothing rules: Lemur retrieval parameters" << endl;
}

bool startWith(std::string content, std::string prefix){
	if(content.substr(0, prefix.size()) == prefix) {
		return true;
	}
	return false;
}

class DDParser {
public:
	std::unordered_map<std::string, struct domain_data> tasks;

        DDParser(std::string topics_file, indri::api::Parameters &p) : param(p)
        {
                std::ifstream xml_file(topics_file.c_str());
                std::string content;
		std::string buffer;
		int lineCT = 0;
                while (getline(xml_file, buffer)){
			 std::string::size_type tag_start = buffer.find("<",0);
                         std::string::size_type tag_end = buffer.find(">",0);

			 if(tag_start!=std::string::npos && tag_end !=std::string::npos){
                                if(tag_end > tag_start){
                                        string first_tag = buffer.substr(tag_start, tag_end - tag_start + 1);
					if(startWith(first_tag,"<domain")){
						struct domain_data task;

						std::string::size_type tag_name_begin = first_tag.find("name=\"",0);
						std::string substring = first_tag.substr(tag_name_begin + 6);
                         			std::string::size_type tag_name_end = substring.find("\"",0);
						std::string attr = substring.substr(0, tag_name_end);
						task.name = attr;
						domain = task.name;

						std::string::size_type tag_id_begin = first_tag.find("id=\"",0);
						substring = first_tag.substr(tag_id_begin + 4);
                                                std::string::size_type tag_id_end = substring.find("\"",0);
                                                attr = substring.substr(0, tag_id_end);			
						task.id = atoi(attr.c_str());

						tasks[domain] = task;
					}

					if(startWith(first_tag,"<topic")){
						struct domain_data & task = tasks[domain];

                        			struct topic_data topic;

                                                std::string::size_type tag_name_begin = first_tag.find("name=\"",0);
						std::string substring = first_tag.substr(tag_name_begin + 6);
                                                std::string::size_type tag_name_end = substring.find("\"",0);

                                                std::string attr = substring.substr(0, tag_name_end);
                                                topic.name = attr;

                                                std::string::size_type tag_id_begin = first_tag.find("id=\"",0);
						substring = first_tag.substr(tag_id_begin + 4);
                                                std::string::size_type tag_id_end = substring.find("\"",0);

                                                attr = substring.substr(0, tag_id_end);
                                                topic.id = atoi(attr.c_str());
						
						task.topics.push_back(topic);
                                        }	
				}
			 }
		}

		index = param.get("index", "");
		run = param.get("runid","");
		config = param.get("config","");
		count = param.get("count", 200); 
                environment.addIndex(index);
                std::vector<std::string> rule;
                if (param.exists("rule")) {
                        indri::api::Parameters slice = param["rule"];
                        for (int i=0; i<slice.size(); ++i) {
                                rule.push_back(slice[i]);
                        }
                        environment.setScoringRules(rule);
                }

		param_domain = param.get("domain", "");
        }
        ~DDParser() {}
        
        //clean special characters in the queries
        std::map<std::string, double> clean_query(std::string query)
        {
                int found = query.find("&amp;amp;");
                while (found!=std::string::npos) {
                        query[found] = ' ';
                        found = query.find("&amp;amp;", found+1);
                }
                found = query.find("\'s");
                while (found!=std::string::npos) {
                        query[found++] = ' ';
                        query[found++] = ' ';
                        found = query.find("\'s");
                }
		found = query.find("OR");
                while (found!=std::string::npos) {
                        query[found++] = ' ';
                        query[found++] = ' ';
                        found = query.find("OR");
                }		

		std::string punctuation;
                punctuation = "-+&:?.,!;{}[]<>()*/\\";
                found = query.find_first_of(punctuation);
                while (found!=std::string::npos) {
                        query[found] = ' ';
                        found = query.find_first_of(punctuation, found+1);
                }
                //return query;
                indri::parse::KrovetzStemmer stemmer;
                std::stringstream query_stream(query);
                std::map<std::string, double> buffer;
                std::string word;
		std::string phrase_word;
                while (query_stream >> word) {
			if (word.find("\"") != word.npos){
				word[word.find("\"")] = ' ';
				phrase_word = word;
				while ((phrase_word.find("\"") == phrase_word.npos) && (query_stream >> word)){
					phrase_word += " ";
					phrase_word += word;
				}
				word = phrase_word;
			}
		        if (word.find("\"") != word.npos){
				word[word.find("\"")] = ' ';
			}
			if (word[0]==' '){
				word = word.substr(1, word.length()-1);
			}
			word.erase(word.find_last_not_of(" \n\r\t")+1);	
                        char *cp = const_cast<char *>(word.c_str());
                        std::string stemmed_word = stemmer.kstem_stemmer(cp);
                        buffer[stemmed_word]++;
                }
                return buffer;
        }

	std::string build_query(std::string original_query){
		std::map<std::string, double> terms  = clean_query(original_query);
		std::stringstream result;

		for (std::map<std::string, double>::iterator it=terms.begin(); it!=terms.end(); ++it)
    			result << it->first << " ";

		return result.str();
	}

	bool terminate(std::vector<indri::api::ScoredExtentResult> rsList, int topic_id, int iteration){
        	call_jig(rsList, topic_id);

		if(rsList.size() ==0 || iteration >= 10){
			return true;
		}else{
			return false;
		}
	}	

	bool call_jig(std::vector<indri::api::ScoredExtentResult> rsList, int topic_id){
		std::vector<std::string> result_doc_no;
                result_doc_no = environment.documentMetadata(rsList, "docno");

		std::stringstream ls;
                for(int i=0; i< result_doc_no.size(); i++){
			ls << result_doc_no[i] << " ";
                }

		//call another executable
		std::stringstream ss;
		ss << topic_id;
		//soft matching
                //std::string command = "python jig/jig.py -r " + run + " -i " + index +  " -o mode1 " + ss.str() + " ";
                
                //exactly matching
                std::string command = "python jig/jig.py -c " + config + " step " + ss.str() + " ";
    		command += ls.str();

		char * para = new char[command.length() + 1];
		std::strcpy(para, command.c_str());

    		std::string output = exec(para);

		cout << "feedback:" << output << endl;

		delete [] para;

        	return true;
	}

	std::vector<indri::api::ScoredExtentResult> generateRSList(std::string query, int iteration){
		std::vector<indri::api::ScoredExtentResult> result;
                result = environment.runQuery(query, count);

        	std::vector<indri::api::ScoredExtentResult> rslt;

		for(int i=(iteration-1)*5; i < result.size() && i< iteration*5; i++){
			rslt.push_back(result[i]);
		}

        	return rslt;
	}

	void print_tasks(){
		std::unordered_map<std::string,struct domain_data>::iterator it;
		for ( it = tasks.begin(); it != tasks.end(); ++it) {
			struct domain_data & task = it->second;
			cout << "domain name:" << task.name << endl;
			cout << "domain id:" << task.id << endl;
			//cout << "domain num_of_topics:" <<task.num_of_topics << endl;

			for(int i=0; i<task.topics.size(); i++){
				struct topic_data & topic = task.topics[i];
				cout << "topic name:" << topic.name << endl;
				cout << "topic id:" << topic.id << endl;
				//cout << "topic num_of_subtopics:" << topic.num_of_subtopics << endl;
				continue;

				for(int j=0; j<topic.subtopics.size(); j++){
					struct subtopic_data & subtopic = topic.subtopics[j];
					cout << "subtopic name:" << subtopic.name << endl;
					cout << "subtopic id:" << subtopic.id << endl;
					cout << "subtopic num_of_passages:" << subtopic.num_of_passages << endl;

					for(int m=0; m<subtopic.passages.size();m++){
						struct passage_data & passage = subtopic.passages[m];
						cout << "passage id:" << passage.id << endl;
						cout << "passage docno:" << passage.docno << endl;
						cout << "passage rating:" << passage.rating << endl;
						cout << "passage text:" << passage.text << endl;
					}
				}

				cout << "----------------------" << endl;
			} 
  		}

	}


private:
        indri::api::QueryEnvironment environment;
	indri::api::Parameters &param;
	std::string domain;
	std::string param_domain;
	int count;
	std::string index;
	std::string run;
	std::string config;
};


int main(int argc, char **argv)
{
        indri::api::QueryEnvironment environment;

        try {
		//read parameters from the command line
                indri::api::Parameters &param = indri::api::Parameters::instance();
                param.loadCommandLine(argc, argv);
                if (!param.exists("topics")|| !param.exists("domain") || !param.exists("runid") || !param.exists("index") || !param.exists("config")) {
                        print_usage(argv[0]);
                        LEMUR_THROW( LEMUR_MISSING_PARAMETER_ERROR, "Must specify topics file,domain, run id, index path and configuration file for jig." );
                }
                std::string index = param.get("index");
                std::string topic_file = param.get("topics");
                std::string run = param.get("runid");
		std::string domain = param.get("domain");
                int count = param.get("count", 200);
		int topicNum = param.get("topicNum", -1); 
                std::vector<std::string> rule;
                if (param.exists("rule")) {
                        indri::api::Parameters slice = param["rule"];
                        for (int i=0; i<slice.size(); ++i) {
                                rule.push_back(slice[i]);
                        }
                        environment.setScoringRules(rule);
                }
                
		//build lemur search enviroment
                environment.addIndex(index);

		//check if topic data existed
		std::ifstream file(topic_file.c_str());
     		if(!file){
			cout << "topic file is not located at path:" << topic_file << endl;
			return -1;
     		}

		//read and parse topics.xml
		DDParser dd_parser(topic_file, param);

		//dd_parser.print_tasks();

                std::ofstream result_RL4(("output/" + run).c_str(), std::ios_base::app);
		struct domain_data & task = dd_parser.tasks[domain];
		
		for (int i=0; i<task.topics.size(); ++i) {
		    struct topic_data & topic = task.topics[i];

                    if(topicNum!=-1 && topicNum != topic.id)
                    {
              	    	continue;
                    }
		    
		    //using topic name as query and clean specific characters in the query
                    std::string expanded_query = dd_parser.build_query(topic.name);
		    if(trim(expanded_query).empty()){
			continue;
		    }
		    cout << "topic " << topic.id << " query:" << topic.name << endl;
		    
		    std::vector<indri::api::ScoredExtentResult> rsList;
		    int iteration = 0;

		    //dynamic search framework
                    do
		    {
			iteration++;

			//generate a retrieval list with 5 docs for each iteration
			rsList = dd_parser.generateRSList(expanded_query, iteration);
			int rank = 0;
                    	std::vector<std::string> result_doc_no;
                    	result_doc_no = environment.documentMetadata(rsList, "docno");
			for(int j=0; j < rsList.size(); j++){
				rank++;
				result_RL4 << topic.id << "\t" << "Q0" << "\t" << result_doc_no[j] << "\t" << rank << "\t" << rsList[j].score << "\t" << run << "\t" << iteration << endl;
				
			}
                    }while(!dd_parser.terminate(rsList, topic.id, iteration)); //call jig, and decide if terminate the retrieval loop based on jig's feedback
                }

		
                environment.close();
        } catch (lemur::api::Exception& e) {
                environment.close();
                LEMUR_ABORT(e);
        } catch (...) {
                environment.close();
                cout << "Caught unhandled exception" << endl;
                return -1;
        }
        return 0;
}

