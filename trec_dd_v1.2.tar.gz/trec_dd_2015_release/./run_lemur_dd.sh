./bin/lemur_dd -topicNum=51 -topics=topics/topics.xml -config=jig/config.yaml -rule=method:d,mu:5000 -domain=Ebola -index=/data1/trecdd/index/ebola_html_01_03_tweets -runid=GU_RUN1
./bin/lemur_dd -topicNum=52 -topics=topics/topics.xml -config=jig/config.yaml -rule=method:d,mu:5000 -domain=Illicit_Goods -index=/data1/trecdd/index/illicitgoods_alldata_0413 -runid=GU_RUN1
./bin/lemur_dd -topicNum=55 -topics=topics/topics.xml -config=jig/config.yaml -rule=method:d,mu:5000 -domain=Local_Politics -index=/data1/trecdd/index/local_politics_50g -runid=GU_RUN1

