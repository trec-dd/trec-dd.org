/*******************************
 * This software is released under an MIT/X11 open source license. Copyright 2015 @ Georgetown University
 *   *******************************/
#include <math.h>
#include <iostream>
#include <stdio.h>
#include <map>
#include <queue>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <utility>
#include <iterator>
#include <indri/QueryEnvironment.hpp>
#include <indri/XMLReader.hpp>
#include <indri/SnippetBuilder.hpp>
#include <indri/KrovetzStemmer.hpp>
#include <indri/QueryExpander.hpp>
#include <indri/RMExpander.hpp>
#include <indri/ParsedDocument.hpp>
#include <unordered_map>

std::string trim(std::string const& str)
{
    if(str.empty())
        return str;

    std::size_t first = str.find_first_not_of(' ');
    std::size_t last  = str.find_last_not_of(' ');
    return str.substr(first, last-first+1);
}


std::map<std::string, double> clean_query(std::string query)
{
        int found = query.find("&amp;amp;");
        while (found!=std::string::npos) {
               query[found] = ' ';
               found = query.find("&amp;amp;", found+1);
        }
        found = query.find("\'s");
        while (found!=std::string::npos) {
               query[found++] = ' ';
               query[found++] = ' ';
               found = query.find("\'s");
        }
	found = query.find("OR");
        while (found!=std::string::npos) {
               query[found++] = ' ';
               query[found++] = ' ';
               found = query.find("OR");
        }		

	std::string punctuation;
        punctuation = "-+&:?.,!;{}[]<>()*/\\";
        found = query.find_first_of(punctuation);
        while (found!=std::string::npos) {
               query[found] = ' ';
               found = query.find_first_of(punctuation, found+1);
        }
        //return query;
        indri::parse::KrovetzStemmer stemmer;
        std::stringstream query_stream(query);
        std::map<std::string, double> buffer;
        std::string word;
	std::string phrase_word;
        while (query_stream >> word) {
	       if (word.find("\"") != word.npos){
		   word[word.find("\"")] = ' ';
	  	   phrase_word = word;
		   while ((phrase_word.find("\"") == phrase_word.npos) && (query_stream >> word)){
			phrase_word += " ";
			phrase_word += word;
		   }
		   word = phrase_word;
	       }
               if (word.find("\"") != word.npos){
			word[word.find("\"")] = ' ';
		}
		if (word[0]==' '){
			word = word.substr(1, word.length()-1);
		}
		word.erase(word.find_last_not_of(" \n\r\t")+1);	
                char *cp = const_cast<char *>(word.c_str());
                std::string stemmed_word = stemmer.kstem_stemmer(cp);
                buffer[stemmed_word]++;
        }
        return buffer;
}

std::string stemming(std::string original_query){
        std::map<std::string, double> terms  = clean_query(original_query);
        std::stringstream result;

        for (std::map<std::string, double>::iterator it=terms.begin(); it!=terms.end(); ++it)
             result << it->first << " ";

        return result.str();
}

void usage(){
  cout << "system parameters missing! 1 parameters needed. agr1 is the sentence waiting for stemming." << endl;
}

#define REQUIRE_ARGS(n) { if( argc < n ) { usage(); return -1; } }

int main ( int argc, char** argv ) {
   try {
       REQUIRE_ARGS(1);
       string content = argv[1];

       content = stemming(content);

       cout << content  << endl;
   } catch ( ... ) {
      cout<< "default error!" << endl;
      return -1;
   }

   return 0;
}


