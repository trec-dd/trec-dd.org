/*******************************
 * This software is released under an MIT/X11 open source license. Copyright 2015 @ Georgetown University
 *   ********************************/
#include <iostream>
using std::cout;
using std::endl;
using std::string;

#include <fstream>
#include <sstream>
#include "ParaSearch.h"
#include <vector>
using std::vector;
#include <unordered_map>
using std::unordered_map;

void usage(){
  cout << "system parameters missing! 2 parameters needed. agr1 is exdocID. arg2 is index path without / end" << endl;
}

#define REQUIRE_ARGS(n) { if( argc < n ) { usage(); return -1; } }

int main ( int argc, char** argv ) {
   try {
       REQUIRE_ARGS(2);
       //query index path
       string exdoc = argv[1];
       string indexPath = argv[2];

       ParaSearch builder(indexPath);

       std::string content = builder.getDocContent(& exdoc);

       cout << content  << endl;
   } catch ( ... ) {
      cout<< "default error!" << endl;
      return -1;
   }

   return 0;
}
