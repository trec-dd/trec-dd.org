/*******************************
 * This software is released under an MIT/X11 open source license. Copyright 2015 @ Georgetown University
 ********************************/
#include "ParaSearch.h"
#include <fstream>
#include <sstream>
#include <list>
#include <time.h>

ParaSearch::ParaSearch(string & indexPath ):_indexPath(indexPath){
  //openIndex();
  _env = NULL;
}

ParaSearch::~ParaSearch(){
   delete _env;
   _env = NULL;
}

char ParaSearch::fromHex(char c1, char c2) {
  char retVal=0;
  if ((c1 > 47) && (c1 < 58)) {
    retVal=(c1-48) << 4;
  } else {
    retVal=(c2-55) << 4;
  }
  if ((c2 > 47) && (c2 < 58)) {
    retVal+=(c2-48);
  } else {
    retVal+=(c2-55);
  }
  return retVal;
}

string ParaSearch::URLDecodeString(string s) {
  stringstream outputString;
  int sLen=s.length();

  int cPos=0;
  while (cPos < sLen) {
    char cChar=s[cPos];
    if (cChar=='+') {
      outputString << " ";
      cPos++;
    } else if (cChar=='%') {
      if ((cPos+2)>=sLen) {
        outputString << cChar;
        cPos++;
      } else {
        char fDigit=s[cPos+1];
        char sDigit=s[cPos+2];
        outputString << fromHex(fDigit, sDigit);
        cPos+=3;
      }
    } else {
      outputString << cChar;
      cPos++;
    }
  }

  return outputString.str();
}

std::string ParaSearch::getDocContent(string *docID){
   openIndex();

   std::vector<std::string> idList;
   idList.push_back(docID->c_str());
   std::vector<lemur::api::DOCID_T> docIDs = 
   _env->documentIDsFromMetadata("docno", idList);
   std::vector<indri::api::ParsedDocument*> documents =
        _env->documents(docIDs);

   indri::api::ParsedDocument* document = documents[0];
   if (document) {
       return document->text;
   }

   return "";
};

void ParaSearch::split(const string &s, char delim, std::vector<string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while(std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return;
}

void ParaSearch::openIndex() {
  if (_env != NULL) return;
  try {
    _env = new indri::api::QueryEnvironment();
    _env->addIndex(_indexPath.c_str());
  } catch (...) {
    _env = NULL;
  }
}
